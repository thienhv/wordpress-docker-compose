<?php

/**
 * Prevent direct access to this file
 */
defined( 'ABSPATH' ) or die();

// Load template archive-nproject
get_template_part( 'archive-nproject' );
