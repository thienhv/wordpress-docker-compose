<?php
defined( 'ABSPATH' ) or die();


/**
 * This class will be present an text control
 * for theme optionsr
 */
class Kiraz_Options_Heading extends Kiraz_Options_Control
{
	/**
	 * The control type
	 * 
	 * @var  string
	 */
	public $type = 'heading';
	
	/**
	 * Render the control markup
	 * 
	 * @return  void
	 */
	public function render_content() {
	}
}
