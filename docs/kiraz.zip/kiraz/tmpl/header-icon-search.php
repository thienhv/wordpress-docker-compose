<li class="search-box">
	<a href="#">
		<i class="iconlab-Search-02-1"></i>
	</a>
	<?php the_widget( 'WP_Widget_Search' ) ?>
</li>